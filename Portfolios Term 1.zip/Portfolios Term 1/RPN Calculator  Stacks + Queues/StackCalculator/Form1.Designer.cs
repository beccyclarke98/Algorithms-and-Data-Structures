namespace StackCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnter = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtTopStack = new System.Windows.Forms.TextBox();
            this.txtStackDisplay = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(278, 87);
            this.btnEnter.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(150, 44);
            this.btnEnter.TabIndex = 0;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(66, 90);
            this.txtData.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(196, 31);
            this.txtData.TabIndex = 1;
            // 
            // txtTopStack
            // 
            this.txtTopStack.Location = new System.Drawing.Point(502, 90);
            this.txtTopStack.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtTopStack.Name = "txtTopStack";
            this.txtTopStack.Size = new System.Drawing.Size(196, 31);
            this.txtTopStack.TabIndex = 2;
            // 
            // txtStackDisplay
            // 
            this.txtStackDisplay.Location = new System.Drawing.Point(502, 179);
            this.txtStackDisplay.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtStackDisplay.Multiline = true;
            this.txtStackDisplay.Name = "txtStackDisplay";
            this.txtStackDisplay.Size = new System.Drawing.Size(196, 173);
            this.txtStackDisplay.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(540, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Top of Stack";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 419);
            this.Controls.Add(this.txtStackDisplay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTopStack);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.btnEnter);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Stack Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtTopStack;
        private System.Windows.Forms.TextBox txtStackDisplay;
        private System.Windows.Forms.Label label1;
    }
}

