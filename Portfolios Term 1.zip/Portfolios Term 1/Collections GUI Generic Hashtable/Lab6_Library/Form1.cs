﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Lab6_Library
{
    public partial class Form1 : Form
    {
        Dictionary<string, Book> libraryDic = new Dictionary<string, Book>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtISBN.Text))
            {
                MessageBox.Show("Enter ID");
                txtISBN.Focus();
                return;
            }
            if (String.IsNullOrEmpty(txtTitle.Text))
            {
                MessageBox.Show("Enter Title.");
                txtISBN.Focus();
                return;
            }
            foreach (var book in libraryDic)
            {
                if (book.Key.Equals(txtISBN.Text))
                {
                    MessageBox.Show("ID already exists.");
                    txtISBN.Clear();
                    txtISBN.Focus();
                    return;
                }
            }
            Book objBook = new Book(txtISBN.Text, txtTitle.Text);
            libraryDic.Add(txtISBN.Text, objBook);
            lstBooks.Items.Add(txtISBN.Text);
            txtISBN.Clear();
            txtTitle.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var book in libraryDic)
            {
                if (book.Key.Equals(txtISBNRemove.Text))
                {
                    libraryDic.Remove(txtISBNRemove.Text);
                    lstBooks.Items.Remove(txtISBNRemove.Text);
                    MessageBox.Show("Book successfully deleted.");
                    txtISBNRemove.Clear();
                    return;
                }
            }
            txtISBNRemove.Clear();
            MessageBox.Show("No Book exists against the ID.");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            lstSearch.Items.Clear();

            lstSearch.Items.Add("ISBN->" + libraryDic[txtsearch.Text].ISBN + " :: Book Title->" + libraryDic[txtsearch.Text].Title + " :: On Loan->" + ((libraryDic[txtsearch.Text].Onloan == true) ? "Yes" : "No"));
        }

        private void btnStatusChange_Click(object sender, EventArgs e)
        {
            if (lstBooks.SelectedItems.Count == 0)
            {
                MessageBox.Show("Select book to change loan status.");
                return;
            }
            foreach (var book in libraryDic)
            {
                Book objbook = (Book)book.Value;
                if (objbook.ISBN.Equals(lstBooks.SelectedItem.ToString()))
                {
                    if (objbook.Onloan)
                    {
                        objbook.Onloan = false;
                        libraryDic[objbook.ISBN] = objbook;
                        MessageBox.Show("Book status successfully changed.");
                        return;
                    }
                    else
                    {
                        objbook.Onloan = true;
                        libraryDic[objbook.ISBN] = objbook;
                        MessageBox.Show("Book status successfully changed.");
                        return;
                    }
                }
            }
        }

        private void lstBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstBooks.SelectedIndex >= 0)
            {
                foreach (var book in libraryDic)
                {
                    Book objbook = (Book)book.Value;
                    if (objbook.ISBN.Equals(lstBooks.SelectedItem.ToString()))
                    {
                        lblISBN.Text = objbook.ISBN;
                        lblTitle.Text = objbook.Title;
                        if (objbook.Onloan)
                        {
                            lblONloan.Text = "Yes";
                            return;
                        }
                        else
                        {
                            lblONloan.Text = "No";
                            return;
                        }
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
