﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_LinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkList testList = new LinkList();
            
            testList.AddItem(1);
            testList.AddItem(2);
            testList.AddItem(3);
            Console.WriteLine(testList.IsPresentItem(1));
            testList.RemoveItem(3);
            testList.DisplayItems();
           
            Console.ReadKey();
        }

    }
}
