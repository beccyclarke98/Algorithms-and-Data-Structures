﻿using System;

namespace Lab4_LinkedList
{
    class LinkList
    {
        private Link list = null; //default value – empty list

        public void AddItem(int item) //add item to front of list
        {
            list = new Link(item, list);
        }

        public string DisplayItems() //write items to string and return
        {
            Link temp = list;
            string buffer = "";
            while (temp != null) // move one link and add head to the buffer
            {
                Console.WriteLine(temp.Data);
                temp = temp.Next;
            }
            return buffer;
        }

        public int NumberOfItems() // returns number of items in list
        {
            Link temp = list;
            int count = 0;
            while (temp != null) // move one link and add 1 to count
            {
                temp = temp.Next; // Moves one link
                count = count + 1; // Adds 1 to the count
            }
            return count;
        }

        public bool IsPresentItem(int item)
        {
            Link temp = list;
            bool Result = false;
            while (temp != null) // While list is not equal to null
            {
                if (temp.Data == item) //If the data is the same as item 
                {
                    Result = true; //return the result as true
                }
                temp = temp.Next; //if not keep scanning
            }
            return Result; //When all is scanned return result as false
        }

        public void RemoveItem(int item)
        {
            Link current = list;
            Link previous = null;

            while (current != null) //if list exists 
            {
                if (current.Data == item) //if data is the same as the item
                {
                    if (previous != null) //Checks if there is previous link
                    {
                        previous.Next = current.Next; //makes it point to the number after the item
                        current = current.Next; //Makes current number point to null
                    }
                    else
                    {
                        previous = current; //previous = null
                        current = current.Next; //points to null 
                        list = current; //
                    }
                }
                else
                    previous = current; //looking for number
                current = current.Next; //looking for number
            }
        }
    }
}