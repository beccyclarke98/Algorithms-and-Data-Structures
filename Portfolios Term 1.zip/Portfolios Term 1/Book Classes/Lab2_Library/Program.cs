﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Library
{
    class Program
    {
        static void Main(string[] args)
        {
            Book[] books = new Book[4];  //declare an array of Book

            books[0] = new Book("Moby Dick");
            books[0].Author = new Person("Herman Melville");
            books[0].Author.Age = 72;
            books[1] = new Horror("The Creeping");
            books[1].Author = new Person("Alexandra Sirowy");
            books[1].Author.Age = 32;
            books[2] = new Sci_Fi("Nightflyers");
            books[2].Author.Age = 70;
            books[3] = new PictureBook("Where The Wild Things Are");
            books[3].Author.Age = 84;
            for (int i = 0; i < 2; i++)
            Console.WriteLine(books[0].GetSummary());
            Console.WriteLine(books[1].GetSummary());
            Console.WriteLine(books[2].GetSummary());
            Console.WriteLine(books[3].GetSummary());
            Console.ReadKey();
        }
    }
}

