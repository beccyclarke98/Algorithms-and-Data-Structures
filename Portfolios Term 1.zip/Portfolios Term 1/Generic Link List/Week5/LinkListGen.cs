﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week5
{
    class LinkListGen<T> where T : IComparable
    {
        private LinkGen<T> list;

        public LinkListGen()
        {
        }
        public void AddItem(T item)
        {
            list = new LinkGen<T>(item, list);
        }
        public string DisplayList()
        {
            LinkGen<T> temp = list;
            string buffer = "";
            while (temp != null) // move one link and add head to the buffer
            {
                Console.WriteLine(temp.Data);
                temp = temp.Next;
            }
            return buffer;
        }
        public int NumberOfItems()
        {
            LinkGen<T> temp = list;
            int count = 0;
            while (temp != null) // move one link and add 1 to count
            {
                temp = temp.Next; // Moves one link
                count = count + 1; // Adds 1 to the count
            }
            return count;
        }
        public bool IsPresentItem(T item)
        {
            LinkGen<T> temp = list;
            bool Result = false;
            while (temp != null) // While list is not equal to null
            {
                //if (item.CompareTo(temp.Data)= item) //If the data is the same as item 
                {
                    Result = true; //return the result as true
                }
                temp = temp.Next; //if not keep scanning
            }
            return Result; //When all is scanned return result as false
        }
        public void RemoveItem(T item)
        {
            LinkGen<T> temp = list;
            LinkListGen<T> newList = new LinkListGen<T>();

            while (temp != null)
            {
                if (item.CompareTo(temp.Data) != 0)
                {
                    newList.AppendItem(temp.Data);
                }
                temp = temp.Next;
            }
            list = newList.list;
        }
        public void AppendItem(T item)
        {
            LinkGen<T> temp = list;

            if (temp == null)
            {
                list = new LinkGen<T>(item);
            }
            else
            {
                while (temp.Next != null)
                {
                    temp = temp.Next;
                }
                temp.Next = new LinkGen<T>(item);
            }
        }

        public void Concat(LinkListGen<T> list2)
        {
            LinkGen<T> temp = list2.list;
            while (temp != null)
            {
                AppendItem(temp.Data);
                temp = temp.Next;
            }
        }

        public void Copy(LinkListGen<T> list2)
        {
            LinkGen<T> temp = list2.list;
            while (temp != null)
            {
                Concat(list2);
                temp = temp.Next;
                break;
            }
        }

        public void InsertInOrder(T item)
        {
            LinkGen<T> temp = list;
            LinkListGen<T> newList = new LinkListGen<T>();
            if (list == null)
                newList.AppendItem(item);
             
            else
            {
                Boolean inserted = false;
                while (temp != null)
                {
                    if (item.CompareTo(temp.Data) > 0)
                    {
                        newList.AppendItem(list.Data);
                    }
                    else if (item.CompareTo(temp.Data) < 0 && inserted == false)
                    {
                        newList.AppendItem(item);
                        newList.AppendItem(temp.Data);
                        inserted = true;
                    }
                   
                    temp = temp.Next; //move list along a list

                }
                if (inserted == false)
                {
                    newList.AppendItem(item); //append list.data to new list
                }
            }
            list = newList.list;
        }
    }
}

    //public void Sort()
    // Pre: True
    //Post: list contains items in non-descending order
