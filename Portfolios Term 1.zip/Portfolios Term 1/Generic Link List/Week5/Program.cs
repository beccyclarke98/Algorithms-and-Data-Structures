﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week5
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkListGen<int> myList = new LinkListGen<int>();
            //myList.AddItem(10);
            //myList.AddItem(8);
            //myList.AddItem(12);
            //myList.AddItem(10);
           // myList.AddItem(12);
            //myList.AddItem(11);
            //myList.DisplayList();
            LinkListGen<int> myList2 = new LinkListGen<int>();
            
            //myList2.AddItem(8);
            //myList2.AddItem(4);
           // myList2.AddItem(10);
            myList.InsertInOrder(6);
            myList.InsertInOrder(10);
            myList.InsertInOrder(8);
            //myList.Concat(myList2);

            
            
            //myList.Copy(myList2);
            myList.DisplayList();
            Console.ReadKey();
        }
    }
}
