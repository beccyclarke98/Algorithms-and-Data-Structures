﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree_Lab8
{
    class Program
    {
        static void Main(string[] args)
        {
           
            AVLTree<int> tree = new AVLTree<int>();
            string buf = "";
           
            tree.InsertItem(5);
            tree.InsertItem(10);
            tree.InsertItem(8);
            
            tree.preOrder(ref buf); 
            
            Console.WriteLine(buf);
            Console.ReadKey();
        }
    }
}

