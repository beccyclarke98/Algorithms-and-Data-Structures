﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree_Lab8
{
    class BSTree<T> : BinTree<T> where T:IComparable
    {

        int count;


        public BSTree()
        {
            root = null;
        }

        public void InsertItem(T item)
        {
            insertItem(item, ref root);
            count++;
        }

        private void insertItem(T item, ref Node<T> tree)
        {
            if (tree == null)
                tree = new Node<T>(item);
            else if (item.CompareTo(tree.Data) < 0)
                insertItem(item, ref tree.Left);
            else if (item.CompareTo(tree.Data) > 0)
                insertItem(item, ref tree.Right);
        }

        public void InsetItem(T item)
        {
            insertItem(item, ref root);
        }

        public void inOrder(ref string buffer)
        {
            inOrder(root, ref buffer);
        }

        private void inOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                inOrder(tree.Left, ref buffer);
                buffer += tree.Data.ToString() + ",";
                inOrder(tree.Right, ref buffer);
            }
        }

        public bool Contains(Node<T> tree, int data)
        {
            if(tree == null)
            {
                return false;
            }
            if(data.CompareTo(tree.Data)<0)
            {
                return Contains(tree.Left,data);
            }
            if(data.CompareTo(tree.Data)>0)
            {
                return Contains(tree.Right, data);
            }

            return true;
        }

        public Node<T> Remove(Node<T> tree, int delete)
        { 

            if(tree == null)
            {
                return tree;
            }
            if(delete.CompareTo(tree.Data) < 0)
            {
                tree.Left = Remove(tree.Left, delete);
            }
            if(delete.CompareTo(tree.Data) > 0)
            {
                tree.Right = Remove(tree.Right, delete);
            }
            if (tree.Data.CompareTo(delete) == 0)
            {
                if (tree.Left == null && tree.Right == null)
                {
                    tree = null;
                    return tree;
                }
                else if (tree.Left == null)
                {
                    Node<T> temp = tree;
                    tree = tree.Right;
                    temp = null;
                }
                else if (root.Right == null)
                {
                    Node<T> temp = tree;
                    tree = tree.Left;
                    temp = null;
                }
                else
                {
                    Node<T> min = FindMin(tree);
                    tree.Data = min.Data;
                    int number = Convert.ToInt32(min.Data);
                    tree.Right = Remove(tree.Right, number);
                }
            }
            return tree;
        }

        public Node<T> FindMin(Node<T> tree)
        {
            tree = tree.Right;
            while (tree.Left != null)
            {
                    tree = tree.Left;
            }

            return tree;
        }

        public void DeleteNode(int x)
        {
            
        }
        public int findHeight(Node<T> temp)
        {
            if(root == null)
            {
                Console.WriteLine("this tree is empty");
                return 0;
            }
            else
            {
                int leftHeight = 0, rightHeight = 0;

                if(temp.Left!=null)
                {
                    leftHeight = findHeight(temp.Left);
                }
                if(temp.Right!=null)
                {
                    rightHeight = findHeight(temp.Right);
                }

                int max = (leftHeight>rightHeight) ? leftHeight: rightHeight;

                return (max + 1);
            }
        }

        public int Count()
        {
            return count;
        }
        
    }

}
