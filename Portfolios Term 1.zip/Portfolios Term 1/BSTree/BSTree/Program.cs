﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSTree
{
    class Program
    {
        static void Main(string[] args)
        {
            BSTree<int> tree = new BSTree<int>();
            tree.InsertItem(10);
            tree.InsertItem(5);
            tree.InsertItem(15);
            tree.InsertItem(12);
            tree.InsertItem(20);
            tree.InsertItem(25);
            tree.InsertItem(30);

            BSTree<String> tree1 = new BSTree<String>();
            tree1.InsertItem("BRG");
            tree1.InsertItem("[BXX]");
            tree1.InsertItem("200");
            tree1.InsertItem("348");
            tree1.InsertItem("5432");
            tree1.InsertItem("789");

            tree1.InsertItem("WLM");
            tree1.InsertItem("456");
            tree1.InsertItem("800");
            tree1.InsertItem("2345");
            tree1.InsertItem("100");
            tree1.InsertItem("[YYY]");


            Console.WriteLine("Height = " + tree1.Height());
            Console.WriteLine("Count = " + tree1.Count());
            String Buf = "";
            tree1.PreOrder(ref Buf);
            Console.WriteLine(Buf);

            //Console.WriteLine("Number of nodes = " + tree.Count());

            //Console.WriteLine(tree.Contains(tree.root, 10));

            //tree.RemoveItem(10, ref tree.root);
            //Console.WriteLine("Removed 10");

            //String Buf = "";
            //tree.PreOrder(ref Buf);
            //tree.InOrder(ref Buf);
            //Console.WriteLine(Buf);


            Console.ReadKey();

        }
    }

    class Node<T> where T : IComparable
    {
        private T data;
        public Node<T> Left, Right;

        public Node(T item)
        {
            data = item;
            Left = null;
            Right = null;
        }
        public T Data
        {
            set { data = value; }
            get { return data; }
        }
    }

    class BinTree<T> where T : IComparable
    {
        public Node<T> root;
        public BinTree()  //creates an empty tree
        {
            root = null;
        }
        public BinTree(Node<T> node)  //creates a tree with node as the root
        {
            root = node;
        }

        public void InOrder(ref string buffer)
        {
            inOrder(root, ref buffer);
        }

        public void inOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                inOrder(tree.Left, ref buffer);
                buffer += tree.Data.ToString() + " , ";
                inOrder(tree.Right, ref buffer);
            }
        }

        public void PreOrder(ref string buffer)
        {
            preOrder(root, ref buffer);
        }

        public void preOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                buffer += tree.Data.ToString() + " , ";
                inOrder(tree.Left, ref buffer);
                inOrder(tree.Right, ref buffer);
            }
        }

        public void PostOrder(ref string buffer)
        {
            postOrder(root, ref buffer);
        }

        public void postOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                inOrder(tree.Left, ref buffer);
                inOrder(tree.Right, ref buffer);
                buffer += tree.Data.ToString() + " , ";
            }
        }
    }

    class BSTree<T> : BinTree<T> where T : IComparable
    {
        int numberofitemsintree;

        public BSTree()
        {
            root = null;

        }

        public void InsertItem(T item)
        {
            insertItem(item, ref root);
            numberofitemsintree++;
        }

        private void insertItem(T item, ref Node<T> tree)
        {
            if (tree == null)
                tree = new Node<T>(item);

            else if (item.CompareTo(tree.Data) < 0)
                insertItem(item, ref tree.Left);

            else if (item.CompareTo(tree.Data) > 0)
                insertItem(item, ref tree.Right);
        }

        public int Height()
        {
            return height(this.root);
        }

        public int height(Node<T> node)
        //Return the max level of the tree
        {
            if (node == null)
            {
                return 0;
            }
            else
            {
                int length12 = height(node.Left);
                int length123 = height(node.Right);
                return 1 + Math.Max(length12, length123);
            }
        }

        public int Count()
        {
            return Count(this.root);
        }

        public int Count(Node<T> node)
        {
            if (node == null)
            {
                return 0;
            }
            if (node.Left == null && node.Right == null)
            {
                return numberofitemsintree / 2;
            }
            else
            {
                return Count(node.Left) + Count(node.Right);
            }
        }

        public Boolean Contains(Node<T> node, T item)
        {
            if (node == null)
            {
                return false;
            }


            if (item.CompareTo(node.Data) < 0)
            {
                return Contains(node.Left, item);
            }

            if (item.CompareTo(node.Data) > 0)
            {
                return Contains(node.Right, item);
            }

            return true;

        }

        public void RemoveItem(T item, ref Node<T> tree)
        {
            if (tree == null)
            {

            }
            else if (item.CompareTo(tree.Data) < 0)
            {
                RemoveItem(item, ref tree.Left);
            }
            else if (item.CompareTo(tree.Data) > 0)
            {
                RemoveItem(item, ref tree.Right);
            }

            //FOUND ITEM
            else
            {
                if (tree.Left == null)
                {
                    tree = tree.Right;
                }
                else if (tree.Right == null)
                {
                    tree = tree.Left;
                }

                else
                {
                    T newRoot = leastItem(ref tree.Right);
                    tree.Data = newRoot;
                    RemoveItem(newRoot, ref tree.Right);
                }
            }
        }

        private T leastItem(ref Node<T> tree)
        {
            if (tree.Left == null)
            {
                return tree.Data;
            }
            else
            {
                return leastItem(ref tree.Left);
            }
        }
    }
}