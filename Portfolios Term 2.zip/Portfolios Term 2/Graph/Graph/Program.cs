﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class Program
    {
        static void Main(string[] args)
        {

            GraphNode<int> current;
            Graph<int> myGraph = new Graph<int>();
            List <int> visited = new List<int>();

            myGraph.AddNode(0);
            myGraph.AddNode(1);
            myGraph.AddNode(2);
            myGraph.AddNode(3);
            myGraph.AddNode(4);
            myGraph.AddNode(5);
            myGraph.AddNode(6);

            myGraph.AddEdge(0,1);
            myGraph.AddEdge(0,2);            
            myGraph.AddEdge(1,3);
            myGraph.AddEdge(4,1);
            myGraph.AddEdge(6,4);
            myGraph.AddEdge(6,0);
            myGraph.AddEdge(5,2);
            myGraph.AddEdge(5,6);

            current = myGraph.GetNodeByID(6);

            myGraph.DepthFirstTraverse(current.ID,ref visited);
            myGraph.MotherVertices();



            Console.Write("Depth First Traversal List: ");
            for (int i =0; i<visited.Count; i++)
            {
                Console.Write(visited[i]+" ");
            }
            Console.WriteLine("------------------------------");

            Console.Write("Mother Vertices List: ");
            List<int> motherV = myGraph.MotherVertices();
            for (int i = 0; i < motherV.Count; i++)
            {
                Console.WriteLine(motherV[i] + " ");
            }
            Console.WriteLine();

            Console.ReadKey();
        }
    }
}
