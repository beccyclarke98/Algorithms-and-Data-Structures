﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    public class Graph<T> where T : IComparable
    {
        // list of all nodes in the graph
        private LinkedList<GraphNode<T>> nodes;


        // constructor – set nodes to new empty list
        public Graph()
        {
            nodes = new LinkedList<GraphNode<T>>();
        }


        // only returns true if the graph’s list of nodes is empty
        public bool IsEmptyGraph()
        {
            return nodes.Count == 0;

        }



        // only returns true if node is present in the graph
        public bool ContainsGraph(GraphNode<T> node)
        {
            //search based on ID 
            foreach (GraphNode<T> n in nodes)
            {
                if (n.ID.CompareTo(node.ID) == 0)
                    return true;
            }
            return false;
        }

        // add a new node (with this “id”) to the list of nodes
        public void AddNode(T id)
        {
            GraphNode<T> n = new GraphNode<T>(id);
            nodes.AddFirst(n);

        }

        //returns the node with this id
        public GraphNode<T> GetNodeByID(T id)
        {

            foreach (GraphNode<T> n in nodes)
            {
                if (n.ID.CompareTo(id) == 0)
                    return n;
            }
            return null;
        }


        // only returns true if nodes “from “ and “to” are adjacent
        public bool IsAdjacent(GraphNode<T> from, GraphNode<T> to)
        {

            foreach (GraphNode<T> n in nodes)
            {
                if (n.ID.CompareTo(from.ID) == 0)
                {
                    if (from.GetAdjList().Contains(to.ID))
                    {
                        return true;
                    }

                }       
            }
            return false;
        }


        // Add a directed edge between the node with id "from" and the node with id “to” 
        public void AddEdge(T from, T to)
        {
            GraphNode<T> a = GetNodeByID(from);
            GraphNode<T> b = GetNodeByID(to);

            foreach (GraphNode<T> n in nodes)
            {
                if (n.ID.CompareTo(a.ID) == 0)
                {
                    n.AddEdge(b);
                }
            } 
        }

              
        //Perform a DFS traversal starting at the node with id “startID”
        //leaving a list of visited id’s in the visited list. 

        public void DepthFirstTraverse(T startID, ref List<T> visited)
        {
            Stack<T> toVisit = new Stack<T>();

            toVisit.Push(startID);

            LinkedList<T> adj;
            GraphNode<T> current = new GraphNode<T>(startID);
            

            while (toVisit.Count != 0)
            {
                
                current.ID = toVisit.Pop();
                visited.Add(current.ID);
                adj = current.GetAdjList();
                
                foreach (var n in GetNodeByID(current.ID).GetAdjList())
                {
                    if ((toVisit.Contains(n) == false) && (visited.Contains(n) == false))
                    {
                        toVisit.Push(n);
                    }
                    
                }

            }
        }
        public List<T> MotherVertices() {
            List<T> motherV = new List<T>();
            //adding all th nodes of graph in allNodes
            List<T> allNodes = new List<T>();
            foreach (GraphNode<T> n in this.nodes) {
                allNodes.Add(n.ID);
            }
            //looping through one node at a time
            foreach (T n in allNodes){
                //getting the visited list for each node
                List<T> visited = new List<T>();
                DepthFirstTraverse(n, ref visited);
                //if visited has all nodes of allNodes, it is mother vertice            
                if (this.ListEq(visited, allNodes)){
                    motherV.Add(n);
                }
            }
            return motherV;
        }

        private Boolean ListEq(List<T> visited, List<T> nodes){
            Boolean check1 = false;
            Boolean check2 = false;
            foreach (T n in visited){
                if (nodes.Contains(n)){
                    check1 = true;
                }

                else{
                    check1 = false;
                    break;
                }
            }
            foreach (T n in nodes){
                if (visited.Contains(n)){
                    check2 = true;
                }

                else{
                    check2 = false;
                    break;
                }
            }

            return (((check1 == true) && (check2 == true)));
        }
    }
}
