﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookSortingEx
{
    class Program
    {
        static void SelectionSort(Book[] arrLibrary)
        {
            int pos_min;
            Book tempBook;
            for (int i = 0; i < arrLibrary.Length - 1; i++)
            {
                pos_min = i; 
                for (int j = i + 1; j < arrLibrary.Length; j++)
                {
                    if (arrLibrary[j].CompareTo(arrLibrary[pos_min]) < 0)
                    {
                        pos_min = j;
                    }
                }
                if (pos_min != i)
                {
                    tempBook = arrLibrary[i];
                    arrLibrary[i] = arrLibrary[pos_min];
                    arrLibrary[pos_min] = tempBook;
                }
            }
        }
        static void Main(string[] args)
        {
            string[] titles = {"Writing Solid Code","Objects First","Programming Gems","Head First Java","The C Programming Language",
                "Mythical Man Month","The Art of Programming","Coding Complete","Design Patterns","ZZ"};
            string[] authors = { "Maguire", "Kolling", "Bentley", "Sierra", "Richie", "Brooks", "Knuth", "McConnal", "Gamma", "Weiss" };
            int[] isbns = { 948343, 849328493, 38948932, 394834342, 983492389, 84928334, 4839455, 21331322, 348923948, 43893284, 9483294, 9823943 };
            Book[] library = new Book[10];
            for (int i = 0; i < library.Length; i++)
            {
                library[i] = new Book(isbns[i], titles[i], authors[i]);
            }
            // Call selection sort to sort the books in the library
            SelectionSort(library);
            //Output the library array after sortion
            for (int i = 0; i < library.Length; i++)
            {
                Console.WriteLine("ISBN: " + library[i].ISBN.ToString() + " Title: " + library[i].Title + " Author: " + library[i].Author);
            }
            Console.ReadKey();
        }
    }
}
