﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookSortingEx
{
    class Book : IComparable<Book>
    {
        public int ISBN;
        public string Title;
        public string Author;
        public Book(int ISBN, string Title, String Author)
        {
            this.ISBN = ISBN;
            this.Title = Title;
            this.Author = Author;
        }
        public override string ToString()
        {
            return Title + " by " + Author + " ISBN: " + ISBN;
        }
        public int CompareTo(Book other)
        {
            return this.ISBN.CompareTo(other.ISBN);
        }

    }
}
