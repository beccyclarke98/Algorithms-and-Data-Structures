﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmnsAssignment
{
    public class BinTree
    {
        protected Node root;

        public BinTree()
        {
            root = null;
        }

        public void SortingTree(ref ArrayList CompanyList)
        {
            sortingTree(root, ref CompanyList);
        }

        private void sortingTree(Node tree, ref ArrayList CompanyList)
        {
            if (tree != null)
            {
                sortingTree(tree.Left, ref CompanyList);
                CompanyList.Add(tree.Data.CompanyName);
                sortingTree(tree.Right, ref CompanyList);
            }
        }
    }
}
