﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlgorithmnsAssignment
{
    public partial class CompanyE : Form
    {
        private Company selectedCompany;
        private AVLTree companyTree;

        public CompanyE(Company selectedCompany, ref AVLTree companyTree)
        {
            this.selectedCompany = selectedCompany;
            this.companyTree = companyTree;
            InitializeComponent();
        }

        private void CompanyE_Load(object sender, EventArgs e)
        {
            CompanyNametxt.Text = selectedCompany.CompanyName;
            NetIncomeTxt.Text = selectedCompany.NetIncome.ToString();
            OperatingIncomeTxt.Text = selectedCompany.OperatingIncome.ToString();
            TotalAssetsTxt.Text = selectedCompany.TotalAssets.ToString();
            NumberOfEmployeesTxt.Text = selectedCompany.NumberOfEmployees.ToString();
            BuyersListBox.DataSource = selectedCompany.Buyers;
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            selectedCompany.NetIncome = Int16.Parse(NetIncomeTxt.Text);
            selectedCompany.OperatingIncome = Int16.Parse(OperatingIncomeTxt.Text);
            selectedCompany.TotalAssets = Int32.Parse(TotalAssetsTxt.Text);
            selectedCompany.NumberOfEmployees = Int32.Parse(NumberOfEmployeesTxt.Text);

            this.Close();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
