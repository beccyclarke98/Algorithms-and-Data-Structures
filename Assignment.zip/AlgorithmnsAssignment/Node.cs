﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmnsAssignment
{
    public class Node
    {
        private Company data;
        public Node Left, Right;
        private int balanceFactor = 0;

        public Node(Company item)
        {
            data = item;
            Left = null;
            Right = null;
        }

        public Company Data
        {
            set { data = value; }
            get { return data; }
        }
        public int BalanceFactor
        {
            set { balanceFactor = value; }
            get { return balanceFactor; }
        }
    }
}