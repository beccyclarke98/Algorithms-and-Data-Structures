﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmnsAssignment
{
    public class AVLTree : BSTree
    {
        new public void InsertItem(Company item)
        {
            insertItem(item, ref root);
        }

        private void insertItem(Company item, ref Node tree)
        {
            if (tree == null)
            {
                tree = new Node(item);
            }
            else if (item.CompareTo(tree.Data) < 0)
            {
                insertItem(item, ref tree.Left);
            }
            else if (item.CompareTo(tree.Data) > 0)
            {
                insertItem(item, ref tree.Right);
            }
            tree.BalanceFactor = Height(tree.Left) - Height(tree.Right);

            if (tree.BalanceFactor <= -2)
            {
                rotateLeft(ref tree);
            }
            if (tree.BalanceFactor >= 2)
            {
                rotateRight(ref tree);
            }
        }

        private void rotateLeft(ref Node tree)
        {

            if (tree.Right.BalanceFactor > 0)  //double rotate
                rotateRight(ref tree.Right);

            Node oldRoot = tree;
            Node newRoot = tree.Right;
            tree = newRoot;

            if (newRoot.Left != null)
            {
                oldRoot.Right = newRoot.Left;
            }
            else
            {
                oldRoot.Right = null;
            }
            newRoot.Left = oldRoot;

        }

        private void rotateRight(ref Node tree)
        {
            if (tree.Left.BalanceFactor < 0)  //double rotate
                rotateLeft(ref tree.Left);


            Node oldRoot = tree;
            Node newRoot = tree.Left;
            tree = newRoot;

            if (newRoot.Right != null)
            {
                oldRoot.Left = newRoot.Right;
            }
            else
            {
                oldRoot.Left = null;
            }
            newRoot.Right = oldRoot;

        }

        public List<String> Search(string searchTerm)
        {
            if (root == null)
            {
                return null;
            }
            List<String> CompanyList = new List<String>();
            return search(searchTerm, root, ref CompanyList);
        }

        private List<String> search(string SearchTextEntered, Node tree, ref List<String> list)
        {
            // Finds match and compares similar countries
            if (tree.Data.CompanyName.ToLower().Contains(SearchTextEntered.ToLower()))
            {
                // List doesn't already contain tree.Data.CountryName
                if (list == null || !list.Contains(tree.Data.CompanyName))
                {
                    list.Add(tree.Data.CompanyName);
                }
                // Looks left to see if match found
                if (tree.Left != null && tree.Left.Data.CompanyName.ToLower().Contains(SearchTextEntered.ToLower()))
                {
                    if (!list.Contains(tree.Left.Data.CompanyName))
                    {
                        list.Add(tree.Left.Data.CompanyName);
                    }
                }
                // Looks right to see if match found
                if (tree.Right != null && tree.Right.Data.CompanyName.ToLower().Contains(SearchTextEntered.ToLower()))
                {
                    if (!list.Contains(tree.Right.Data.CompanyName))
                    {
                        list.Add(tree.Right.Data.CompanyName);
                    }
                }
            }
            else if (SearchTextEntered.ToLower().CompareTo(tree.Data.CompanyName.ToLower()) < 0)
            {
                return search(SearchTextEntered, tree.Left, ref list);
            }
            else
            {
                return search(SearchTextEntered, tree.Right, ref list);
            }
            return list;
        }

    }

}
