﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmnsAssignment
{
    public class BSTree : BinTree
    {

        int count;

        public BSTree()
        {
            root = null;
        }

        public void InsertItem(Company item)
        {
            insertItem(item, ref root);
            count++;
        }

        private void insertItem(Company item, ref Node tree)
        {
            if (tree == null)
                tree = new Node(item);
            else if (item.CompareTo(tree.Data) < 0)
                insertItem(item, ref tree.Left);
            else if (item.CompareTo(tree.Data) > 0)
                insertItem(item, ref tree.Right);
        }

        public Company getCompanyName(String companyName)
        {
            if (root == null)
            {
                return null;
            }

            return contains(companyName, root);
        }

        //Only "CONTAINS" FOR COMPANY NAME
        private Company contains(string companyName, Node tree)
        {
            if (tree == null)
            {
                return null;
            }
            else if (companyName.Equals(tree.Data.CompanyName, StringComparison.OrdinalIgnoreCase))
            {
                return tree.Data;
            }
            else if (companyName.CompareTo(tree.Data.CompanyName) < 0)
            {
                return contains(companyName, tree.Left);
            }
            else
            {
                return contains(companyName, tree.Right);
            }
        }

        public void Remove(Company item)
        {
            if (root != null && Contains(item))
            {
                Remove(item, ref root);
            }
        }

        public Boolean Contains(Company item)
        {
            if (root == null)
            {
                return false;
            }

            return compObjectItemFound(item, root);
        }

        private Boolean compObjectItemFound(Company item, Node tree)
        {
            if (tree == null)
            {
                return false;
            }
            // If country found
            else if (tree.Data.CompareTo(item) == 0)
            {
                return true;
            }

            if (item.CompareTo(tree.Data) < 0)
            {
                return compObjectItemFound(item, tree.Left);
            }
            else
            {
                return compObjectItemFound(item, tree.Right);
            }
        }


        private void Remove(Company item, ref Node tree)
        {
            if (item.CompareTo(tree.Data) < 0)
            {
                Remove(item, ref tree.Left);
            }
            if (item.CompareTo(tree.Data) > 0)
            {
                Remove(item, ref tree.Right);
            }
            if (tree.Data.CompareTo(item) == 0)
            {
                if (tree.Left == null && tree.Right == null)
                {
                    tree = null;

                }
                else if (tree.Left == null)
                {
                    Node temp = tree;
                    tree = tree.Right;
                    temp = null;
                }
                else if (root.Right == null)
                {
                    Node temp = tree;
                    tree = tree.Left;
                    temp = null;
                }
                else
                {
                    Company newroot = FindMin(tree.Right);
                    tree.Data = newroot;
                    Remove(newroot, ref tree.Right);
                }
            }
        }

        private Company FindMin(Node tree)
        {
            if (tree.Left == null)
            {
                return tree.Data;
            }
            else
            {
                return FindMin(tree.Left);
            }
        }

        public int Height()
        {
            if (root == null)
            {
                return 0;
            }
            return findHeightofTree(root);
        }

        public int Height(Node tree)
        {
            if (tree == null)
            {
                return 0;
            }
            return findHeightofTree(tree);
        }

        private int findHeightofTree(Node tree)
        {
            int leftHeight = 0;
            int rightHeight = 0;

            if (tree.Left != null)
            {
                leftHeight = findHeightofTree(tree.Left);
            }
            if (tree.Right != null)
            {
                rightHeight = findHeightofTree(tree.Right);
            }
            if (leftHeight > rightHeight)
            {
                return leftHeight + 1;
            }
            else
            {
                return rightHeight + 1;
            }
        }
    }
}
