﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace AlgorithmnsAssignment
{
    public partial class CompanyForm : Form
    {
        //PUBLIC VARIABLES
        AVLTree CompanyTree = new AVLTree();
        int NumberOfCompanies = 0;

        public CompanyForm()
        {
            InitializeComponent();
        }

        private void CompanyForm_Load(object sender, EventArgs e)
        {
            string[] headers = new string[6]; //Column Headers
            const int MAX_LINES_FILE = 50000;
            string companyName;
            int netIncome;
            int operatingIncome;
            int totalAssets;
            int numberEmployees;
            string[] buyers;

            string[] AllLines = new string[MAX_LINES_FILE];

            //set a string variable with the location of the data file. Use ReadAllLines to read the data        
            string path = @"C:\Users\Rebecca\Desktop\AlgorithmnsAssignment\companies.csv";

            AllLines = File.ReadAllLines(path); foreach (string line in AllLines)

                if (line.StartsWith("Company")) //found first line - headers           
                {
                    headers = line.Split(',');
                }
                else
                {
                    string[] columns = line.Split(',');

                    companyName = columns[0];
                    netIncome = Convert.ToInt16(columns[1]);
                    operatingIncome = Convert.ToInt16(columns[2]);
                    totalAssets = Convert.ToInt32(columns[3]);
                    numberEmployees = Convert.ToInt32(columns[4]); ;
                    buyers = columns[5].Split(';');

                    CompanyTree.InsertItem(new Company(companyName, netIncome, operatingIncome, totalAssets, numberEmployees, buyers));
                    NumberOfCompanies++;
                }
            Console.Read();
            ArrayList Company = new ArrayList();
            CompanyTree.SortingTree(ref Company);
            CompanyListBox.DataSource = Company;

        }

        private void CompanyListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LinkedList<string> BuyersList = new LinkedList<string>();
            string selectedCompanyString = CompanyListBox.SelectedItem.ToString();
            Company selectedCompany = CompanyTree.getCompanyName(selectedCompanyString);

            CompanyNametxt.ReadOnly = true;
            NetIncomeTxt.ReadOnly = true;
            OperatingIncomeTxt.ReadOnly = true;
            TotalAssetsTxt.ReadOnly = true;
            NumberOfEmployeesTxt.ReadOnly = true;

            CompanyNametxt.Text = selectedCompanyString;
            NetIncomeTxt.Text = selectedCompany.NetIncome.ToString();
            OperatingIncomeTxt.Text = selectedCompany.OperatingIncome.ToString();
            TotalAssetsTxt.Text = selectedCompany.TotalAssets.ToString();
            NumberOfEmployeesTxt.Text = selectedCompany.NumberOfEmployees.ToString();
            BuyersListBox.DataSource = selectedCompany.Buyers;

        }

        private void RmvCompanyBtn_Click(object sender, EventArgs e)
        {
            if (BuyersListBox.DataSource != null)
            {
                string selectedCompanyString = CompanyListBox.SelectedItem.ToString();
                Company selectedCompany = CompanyTree.getCompanyName(selectedCompanyString);

                CompanyTree.Remove(selectedCompany);

                CompanyNametxt.Clear();
                NetIncomeTxt.Clear();
                OperatingIncomeTxt.Clear();
                TotalAssetsTxt.Clear();
                NumberOfEmployeesTxt.Clear();
                BuyersListBox.DataSource = null;

            }
            ArrayList Company = new ArrayList();
            CompanyTree.SortingTree(ref Company); //Organising Company List
            CompanyListBox.DataSource = Company;
            NumberOfCompanies--; //Counter
        }

        private void CalculateBtn_Click(object sender, EventArgs e)
        {
            //Tree Height
            int depth = 0;
            depth = CompanyTree.Height();
            TreeDepthTxt.Text = depth.ToString();

            NumberOfCompanyTxt.Text = NumberOfCompanies.ToString(); //Number Of Companies
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            string selectedCompanyString = CompanyListBox.SelectedItem.ToString();
            Company selectedCompany = CompanyTree.getCompanyName(selectedCompanyString);
            CompanyE editor = new CompanyE(selectedCompany, ref CompanyTree);
            editor.Show();
        }

        private void SearchTxt_TextChanged(object sender, EventArgs e)
        {
                string SearchTextEntered = SearchTxt.Text;

                List<string> result = null;
                result = CompanyTree.Search(SearchTextEntered);
                CompanyListBox.DataSource = result;
        }

        private void ClearSearchBtn_Click(object sender, EventArgs e)
        {
            SearchTxt.Clear();
            ArrayList Company = new ArrayList();
            CompanyTree.SortingTree(ref Company); //Organising Company List
            CompanyListBox.DataSource = Company;
        }
    }
}
