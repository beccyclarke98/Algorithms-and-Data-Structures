﻿namespace AlgorithmnsAssignment
{
    partial class CompanyE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BuyersListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CompanyNametxt = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.NetIncomeTxt = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TotalAssetsTxt = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.NumberOfEmployeesTxt = new System.Windows.Forms.MaskedTextBox();
            this.OperatingIncomeTxt = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BuyersListBox
            // 
            this.BuyersListBox.FormattingEnabled = true;
            this.BuyersListBox.ItemHeight = 25;
            this.BuyersListBox.Location = new System.Drawing.Point(269, 304);
            this.BuyersListBox.Name = "BuyersListBox";
            this.BuyersListBox.Size = new System.Drawing.Size(145, 154);
            this.BuyersListBox.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 25);
            this.label2.TabIndex = 17;
            this.label2.Text = "Company";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 245);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(227, 25);
            this.label3.TabIndex = 18;
            this.label3.Text = "Number Of Employees";
            // 
            // CompanyNametxt
            // 
            this.CompanyNametxt.Location = new System.Drawing.Point(269, 9);
            this.CompanyNametxt.Name = "CompanyNametxt";
            this.CompanyNametxt.Size = new System.Drawing.Size(145, 31);
            this.CompanyNametxt.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 304);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 25);
            this.label4.TabIndex = 19;
            this.label4.Text = "Buyers";
            // 
            // NetIncomeTxt
            // 
            this.NetIncomeTxt.Location = new System.Drawing.Point(269, 63);
            this.NetIncomeTxt.Name = "NetIncomeTxt";
            this.NetIncomeTxt.Size = new System.Drawing.Size(145, 31);
            this.NetIncomeTxt.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 184);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 25);
            this.label5.TabIndex = 20;
            this.label5.Text = "Total Assets";
            // 
            // TotalAssetsTxt
            // 
            this.TotalAssetsTxt.Location = new System.Drawing.Point(269, 184);
            this.TotalAssetsTxt.Name = "TotalAssetsTxt";
            this.TotalAssetsTxt.Size = new System.Drawing.Size(145, 31);
            this.TotalAssetsTxt.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 25);
            this.label6.TabIndex = 21;
            this.label6.Text = "Operating Income";
            // 
            // NumberOfEmployeesTxt
            // 
            this.NumberOfEmployeesTxt.Location = new System.Drawing.Point(269, 245);
            this.NumberOfEmployeesTxt.Name = "NumberOfEmployeesTxt";
            this.NumberOfEmployeesTxt.Size = new System.Drawing.Size(145, 31);
            this.NumberOfEmployeesTxt.TabIndex = 24;
            // 
            // OperatingIncomeTxt
            // 
            this.OperatingIncomeTxt.Location = new System.Drawing.Point(269, 119);
            this.OperatingIncomeTxt.Name = "OperatingIncomeTxt";
            this.OperatingIncomeTxt.Size = new System.Drawing.Size(145, 31);
            this.OperatingIncomeTxt.TabIndex = 23;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 25);
            this.label7.TabIndex = 22;
            this.label7.Text = "NET Income";
            // 
            // SaveBtn
            // 
            this.SaveBtn.Location = new System.Drawing.Point(5, 479);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(188, 57);
            this.SaveBtn.TabIndex = 29;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = true;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(226, 479);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(188, 57);
            this.CancelBtn.TabIndex = 30;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // CompanyE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 556);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.BuyersListBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CompanyNametxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NetIncomeTxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TotalAssetsTxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.NumberOfEmployeesTxt);
            this.Controls.Add(this.OperatingIncomeTxt);
            this.Controls.Add(this.label7);
            this.Name = "CompanyE";
            this.Text = "CompanyE";
            this.Load += new System.EventHandler(this.CompanyE_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox BuyersListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox CompanyNametxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox NetIncomeTxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox TotalAssetsTxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox NumberOfEmployeesTxt;
        private System.Windows.Forms.MaskedTextBox OperatingIncomeTxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Button CancelBtn;
    }
}