﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmnsAssignment
{
    public class Company : IComparable<Company>
    {
        private string companyName;
        private int netIncome;
        private int operatingIncome;
        private int totalAssets;
        private int numberEmployees;
        private string[] buyers;

        public Company(string name, int nincome, int opincome, int tlassets, int nmbemployee, string[] buy)
        {
            companyName = name;
            netIncome = nincome;
            operatingIncome = opincome;
            totalAssets = tlassets;
            numberEmployees = nmbemployee;
            buyers = buy;
        }

        public String CompanyName
        {
            get
            {
                return companyName;
            }
            set
            {
                companyName = value;
            }
        }

        public int NetIncome
        {
            get
            {
                return netIncome;
            }
            set
            {
                netIncome = value;
            }
        }

        public int OperatingIncome
        {
            get
            {
                return operatingIncome;
            }
            set
            {
                operatingIncome = value;
            }
        }
        public int TotalAssets
        {
            get
            {
                return totalAssets;
            }
            set
            {
                totalAssets = value;
            }
        }

        public int NumberOfEmployees
        {
            get
            {
                return numberEmployees;
            }
            set
            {
                numberEmployees = value;
            }
        }

        public string[] Buyers
        {
            get
            {
                return buyers;
            }
            set
            {
                buyers = value;
            }
        }

        public int CompareTo(Company other)
        {
            return companyName.CompareTo(other.companyName);
        }
    }

}
