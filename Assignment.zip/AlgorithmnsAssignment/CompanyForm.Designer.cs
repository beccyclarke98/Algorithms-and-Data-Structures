﻿namespace AlgorithmnsAssignment
{
    partial class CompanyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CompanyListBox = new System.Windows.Forms.ListBox();
            this.SearchTxt = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.OperatingIncomeTxt = new System.Windows.Forms.MaskedTextBox();
            this.NumberOfEmployeesTxt = new System.Windows.Forms.MaskedTextBox();
            this.TotalAssetsTxt = new System.Windows.Forms.MaskedTextBox();
            this.NetIncomeTxt = new System.Windows.Forms.MaskedTextBox();
            this.CompanyNametxt = new System.Windows.Forms.MaskedTextBox();
            this.BuyersListBox = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.CalculateBtn = new System.Windows.Forms.Button();
            this.TreeDepthTxt = new System.Windows.Forms.MaskedTextBox();
            this.NumberOfCompanyTxt = new System.Windows.Forms.MaskedTextBox();
            this.RmvCompanyBtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.ClearSearchBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CompanyListBox
            // 
            this.CompanyListBox.FormattingEnabled = true;
            this.CompanyListBox.ItemHeight = 25;
            this.CompanyListBox.Location = new System.Drawing.Point(12, 102);
            this.CompanyListBox.Name = "CompanyListBox";
            this.CompanyListBox.Size = new System.Drawing.Size(369, 729);
            this.CompanyListBox.TabIndex = 0;
            this.CompanyListBox.SelectedIndexChanged += new System.EventHandler(this.CompanyListBox_SelectedIndexChanged);
            // 
            // SearchTxt
            // 
            this.SearchTxt.Location = new System.Drawing.Point(111, 36);
            this.SearchTxt.Name = "SearchTxt";
            this.SearchTxt.Size = new System.Drawing.Size(129, 31);
            this.SearchTxt.TabIndex = 2;
            this.SearchTxt.TextChanged += new System.EventHandler(this.SearchTxt_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Search:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(413, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Company";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(413, 338);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(227, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Number Of Employees";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(413, 397);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Buyers";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(413, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Total Assets";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(413, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Operating Income";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(413, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 25);
            this.label7.TabIndex = 9;
            this.label7.Text = "NET Income";
            // 
            // OperatingIncomeTxt
            // 
            this.OperatingIncomeTxt.Location = new System.Drawing.Point(670, 212);
            this.OperatingIncomeTxt.Name = "OperatingIncomeTxt";
            this.OperatingIncomeTxt.Size = new System.Drawing.Size(145, 31);
            this.OperatingIncomeTxt.TabIndex = 11;
            // 
            // NumberOfEmployeesTxt
            // 
            this.NumberOfEmployeesTxt.Location = new System.Drawing.Point(670, 338);
            this.NumberOfEmployeesTxt.Name = "NumberOfEmployeesTxt";
            this.NumberOfEmployeesTxt.Size = new System.Drawing.Size(145, 31);
            this.NumberOfEmployeesTxt.TabIndex = 12;
            // 
            // TotalAssetsTxt
            // 
            this.TotalAssetsTxt.Location = new System.Drawing.Point(670, 277);
            this.TotalAssetsTxt.Name = "TotalAssetsTxt";
            this.TotalAssetsTxt.Size = new System.Drawing.Size(145, 31);
            this.TotalAssetsTxt.TabIndex = 13;
            // 
            // NetIncomeTxt
            // 
            this.NetIncomeTxt.Location = new System.Drawing.Point(670, 156);
            this.NetIncomeTxt.Name = "NetIncomeTxt";
            this.NetIncomeTxt.Size = new System.Drawing.Size(145, 31);
            this.NetIncomeTxt.TabIndex = 14;
            // 
            // CompanyNametxt
            // 
            this.CompanyNametxt.Location = new System.Drawing.Point(670, 102);
            this.CompanyNametxt.Name = "CompanyNametxt";
            this.CompanyNametxt.Size = new System.Drawing.Size(145, 31);
            this.CompanyNametxt.TabIndex = 15;
            // 
            // BuyersListBox
            // 
            this.BuyersListBox.FormattingEnabled = true;
            this.BuyersListBox.ItemHeight = 25;
            this.BuyersListBox.Location = new System.Drawing.Point(670, 397);
            this.BuyersListBox.Name = "BuyersListBox";
            this.BuyersListBox.Size = new System.Drawing.Size(145, 154);
            this.BuyersListBox.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(413, 703);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 25);
            this.label8.TabIndex = 18;
            this.label8.Text = "Tree Depth";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(413, 767);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(223, 25);
            this.label9.TabIndex = 19;
            this.label9.Text = "Number Of Companys";
            // 
            // CalculateBtn
            // 
            this.CalculateBtn.Location = new System.Drawing.Point(748, 692);
            this.CalculateBtn.Name = "CalculateBtn";
            this.CalculateBtn.Size = new System.Drawing.Size(128, 123);
            this.CalculateBtn.TabIndex = 23;
            this.CalculateBtn.Text = "Calculate";
            this.CalculateBtn.UseVisualStyleBackColor = true;
            this.CalculateBtn.Click += new System.EventHandler(this.CalculateBtn_Click);
            // 
            // TreeDepthTxt
            // 
            this.TreeDepthTxt.Location = new System.Drawing.Point(642, 703);
            this.TreeDepthTxt.Name = "TreeDepthTxt";
            this.TreeDepthTxt.Size = new System.Drawing.Size(100, 31);
            this.TreeDepthTxt.TabIndex = 21;
            // 
            // NumberOfCompanyTxt
            // 
            this.NumberOfCompanyTxt.Location = new System.Drawing.Point(642, 767);
            this.NumberOfCompanyTxt.Name = "NumberOfCompanyTxt";
            this.NumberOfCompanyTxt.Size = new System.Drawing.Size(100, 31);
            this.NumberOfCompanyTxt.TabIndex = 20;
            // 
            // RmvCompanyBtn
            // 
            this.RmvCompanyBtn.Location = new System.Drawing.Point(402, 586);
            this.RmvCompanyBtn.Name = "RmvCompanyBtn";
            this.RmvCompanyBtn.Size = new System.Drawing.Size(202, 83);
            this.RmvCompanyBtn.TabIndex = 22;
            this.RmvCompanyBtn.Text = "Remove Company";
            this.RmvCompanyBtn.UseVisualStyleBackColor = true;
            this.RmvCompanyBtn.Click += new System.EventHandler(this.RmvCompanyBtn_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.Location = new System.Drawing.Point(627, 586);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(188, 83);
            this.EditBtn.TabIndex = 24;
            this.EditBtn.Text = "Edit Company";
            this.EditBtn.UseVisualStyleBackColor = true;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // ClearSearchBtn
            // 
            this.ClearSearchBtn.Location = new System.Drawing.Point(247, 36);
            this.ClearSearchBtn.Name = "ClearSearchBtn";
            this.ClearSearchBtn.Size = new System.Drawing.Size(134, 41);
            this.ClearSearchBtn.TabIndex = 25;
            this.ClearSearchBtn.Text = "Reset";
            this.ClearSearchBtn.UseVisualStyleBackColor = true;
            this.ClearSearchBtn.Click += new System.EventHandler(this.ClearSearchBtn_Click);
            // 
            // CompanyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 843);
            this.Controls.Add(this.ClearSearchBtn);
            this.Controls.Add(this.EditBtn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.BuyersListBox);
            this.Controls.Add(this.CalculateBtn);
            this.Controls.Add(this.RmvCompanyBtn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TreeDepthTxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NumberOfCompanyTxt);
            this.Controls.Add(this.CompanyNametxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NetIncomeTxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SearchTxt);
            this.Controls.Add(this.TotalAssetsTxt);
            this.Controls.Add(this.CompanyListBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.NumberOfEmployeesTxt);
            this.Controls.Add(this.OperatingIncomeTxt);
            this.Controls.Add(this.label7);
            this.Name = "CompanyForm";
            this.Text = "CompanyForm";
            this.Load += new System.EventHandler(this.CompanyForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox CompanyListBox;
        private System.Windows.Forms.MaskedTextBox SearchTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox OperatingIncomeTxt;
        private System.Windows.Forms.MaskedTextBox NumberOfEmployeesTxt;
        private System.Windows.Forms.MaskedTextBox TotalAssetsTxt;
        private System.Windows.Forms.MaskedTextBox NetIncomeTxt;
        private System.Windows.Forms.MaskedTextBox CompanyNametxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox TreeDepthTxt;
        private System.Windows.Forms.MaskedTextBox NumberOfCompanyTxt;
        private System.Windows.Forms.ListBox BuyersListBox;
        private System.Windows.Forms.Button CalculateBtn;
        private System.Windows.Forms.Button RmvCompanyBtn;
        private System.Windows.Forms.Button EditBtn;
        private System.Windows.Forms.Button ClearSearchBtn;
    }
}